self.__precacheManifest = [
  {
    "revision": "455fa98a5d3e49c093e7",
    "url": "./static/js/main.455fa98a.js"
  },
  {
    "revision": "d9ae6a3bb66a0e1b5c0838e72a5897d5",
    "url": "./index.html"
  }
];